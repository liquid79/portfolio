// STYLING FOR MAIN ELEMENT LAYOUT
document.querySelector(".content").style.cssText = "display: grid; grid-gap: 1.5rem; margin-top: -1.5rem";

// STYLING FOR HEADER
document.querySelector(".heading-primary--main").style.cssText = "text-transform: uppercase; font-style: italic";
document.querySelector(".heading-primary--sub").style.cssText = "display: block; transform: skewY(4deg); font-style: normal; margin-top: 1rem";

// STATIC GLITCH EFFECT
document.querySelector(".glitch_static").style.cssText = "position: fixed; pointer-events: none; z-index: 1; height: 200%; width: 200%; left: -50%; top: -50%";

// IMAGE HOVER EFFECTS
let imageGlitch = (imageId, altFileName) => {
	document.getElementById(imageId).src = altFileName;
};